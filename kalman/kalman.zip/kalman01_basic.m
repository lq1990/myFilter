clc;clear;
close all;
% ==============================
% time-varying Kalman Filter design
% params given by user:
% 
% 
% ==============================

dt = 1; % => sampleFreq is 1hz, 1time/1s
size = 100;
a = 0;

t= 1:size;
% Z = dt * t + 0.5*a*t.^2; % observe values�� position is observed, 1m 2m 3m...
Z = 1:100;
std = 5;
noise =std*randn(1, size); % gauss noise with var
Z = Z + noise;

% init state of X,P
X = [0; 0]; % state [p; v]
P = [1 0; 0 1]; % Cov matrix of state
% P = [0,0;0,0];

F = [1 dt; 0 1]; % state transition matrix

B = [dt*dt/2; dt];
u = a;

% we are sure model uncertainty is low
% Q = [0.0001, 0; 0 0.0001]; % Cov matrix of model or outside uncertainty
Q = [0,0; 0,0];

H = [1, 0]; % observe matrix, only position is observed, z = H * [p; v] + r
R = std*std; % observe noise Cov. same as noise with var

figure;
hold on; grid on;

x_pred = zeros(1,size);
v_pred = zeros(1,size);
filtered = zeros(1, size);

for i=1:size
    % predict x_,P_
   X_ = F*X + B*u; % Bu = 0
   P_ = F*P*F'+Q; 
   
   % update x,P using z
   K = P_*H'/(H*P_*H' + R); % kalman coef
   X= X_ + K*(Z(i) - H*X_);
   P = (eye(2) - K*H) * P_; 
   
%    plot(K(1), K(2), 'or'); hold on; grid on;
%    plot(P(1), P(2), 'ob'); hold on; grid on;
%    plot(P(3), P(4), 'og'); hold on; grid on;
   
   x_pred(i) = X(1);
   v_pred(i) = X(2);
   filtered(i) = H*X; % filtered response
   plot(X(1), X(2), 'k.'); % [p, v]
end
xlabel('position');
ylabel('velocity');

figure;
plot(1:size, Z, 'r-.', 'LineWidth', 2); hold on; grid on;
plot(1:size, filtered, 'k', 'LineWidth', 2);
legend('observed position','optimal predicted postion or filtered', 'Location', 'NW');


